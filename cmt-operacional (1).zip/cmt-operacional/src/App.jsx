
export default function App() {
  return (
    <div className="container">
      <header className="topo">
        <h1>CMT Operacional</h1>
        <p>Usina Batatais</p>
      </header>

      <div className="login">
        <h2>Login do Sistema</h2>
        <p><strong>Usuário:</strong> CMT@</p>
        <p><strong>Senha:</strong> Cmt2026</p>
      </div>

      <div className="cards">
        <div className="card">
          <h3>Equipamentos</h3>
          <p>Cadastro de tratores, caminhões e pulverizadores.</p>
        </div>

        <div className="card">
          <h3>Fazendas</h3>
          <p>Controle operacional por fazenda.</p>
        </div>

        <div className="card">
          <h3>Implementos</h3>
          <p>Gerenciamento de implementos agrícolas.</p>
        </div>

        <div className="card">
          <h3>Manutenção</h3>
          <p>Equipamentos em manutenção.</p>
        </div>
      </div>

      <table>
        <thead>
          <tr>
            <th>Equipamento</th>
            <th>Status</th>
            <th>Fazenda</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Trator 102874</td>
            <td>Trabalhando</td>
            <td>Água Limpa 2</td>
          </tr>
          <tr>
            <td>Caminhão 100133</td>
            <td>Parado</td>
            <td>Pátio Usina</td>
          </tr>
          <tr>
            <td>Uniport 101455</td>
            <td>Manutenção</td>
            <td>Oficina</td>
          </tr>
        </tbody>
      </table>
    </div>
  )
}
